#!/bin/sh
if [ $1 -le 1900 ]
then
	echo "Nam khong hop le" > "$3" 
	exit 1
fi

if [ $2 -le 0 ] || [ $2 -ge 13 ]
then
	echo "Thang khong hop le" > "$3"
exit 1
fi

res=0
if [ $2 -eq 1 ] || [ $2 -eq 3 ] || [ $2 -eq 5 ] || [ $2 -eq 7 ] || [ $2 -eq 8 ] || [ $2 -eq 10 ] || [ $2 -eq 12 ]
then
	echo "31" > $3
elif [ $2 -eq 4 ] ||  [ $2 -eq 6 ] ||  [ $2 -eq 9 ] ||  [ $2 -eq 11 ]
then
	echo "30" > 3
else
	if [ 0 -eq "$(( $1 % 4 ))" ] && [ 0 -ne "$(( $1 % 100 ))" ]
       	then
		    echo "29" > "$3"
	elif [ 0 -eq "$(( $1 % 400 ))" ]
	then
		    echo "29" > "$3"
	    else 
		    echo "28" > "$3"
	fi
fi
exit 0


