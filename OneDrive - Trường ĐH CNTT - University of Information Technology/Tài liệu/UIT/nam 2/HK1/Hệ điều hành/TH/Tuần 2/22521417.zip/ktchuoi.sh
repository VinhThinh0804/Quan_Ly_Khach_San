#!/bin/sh
if [ ! -f "$2" ]
then
	    echo "Tập tin $2 không tồn tại" > "$3"
	    exit 1
fi

if grep -q "$1" "$2"
then
	    echo "Trong tập tin $2 có chuỗi $1" > "$3"
    else
	    echo "Trong tập tin $2 không có chuỗi $1" > "$3"
fi

exit 0
